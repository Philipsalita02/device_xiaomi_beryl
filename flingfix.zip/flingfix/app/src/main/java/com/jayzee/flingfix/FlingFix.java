package com.jayzee.flingfix;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Reverts HyperOS's per-package fling glide extension back to stock AOSP timing.
 *
 * Confirmed via static analysis of /system/framework/framework.jar (classes4.dex):
 *   android.widget.UFwScrollerManager
 *     - binder service name: "ultraframework_scroller_feature"
 *     - getFlingFrictionScale(String pkg)  -> float   (cached in mFlingFrictionScale)
 *     - getFlingAnimationScale(String pkg) -> float   (cached in mFlingAnimationScale)
 *     - getFlingAnimationSwitch(String pkg) -> int    (cached in mFlingAnimationSwitch)
 *     - DEFAULT_SCALE = 0.0f (read directly from the static constant pool — this is
 *       the value that means "no scaling applied")
 *
 * android.widget.OverScroller$SplineOverScroller still carries the stock AOSP fields
 * (mFlingFriction, mPhysicalCoeff, mDeceleration) plus Xiaomi/MediaTek additions
 * (mSplineOverScrollerStub, mScrollScenario). The UFwScrollerManager scale is the
 * cleanest, most likely call site feeding into that math, so it's hooked first.
 *
 * Everything logs to logcat (filter: FlingFix) so you can verify on-device which
 * hook actually fires for a touch-driven Instagram fling before trusting any of it.
 */
public class FlingFix implements IXposedHookLoadPackage {

    private static final String TAG = "FlingFix";

    // Flip to true only if logcat shows the UFwScrollerManager hooks never fire
    // for Instagram's fling path. This caps total glide duration directly instead.
    private static final boolean ENABLE_DURATION_CAP_FALLBACK = false;
    private static final int MAX_FLING_DURATION_MS = 600;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!"com.instagram.android".equals(lpp.packageName)) {
            return;
        }

        hookFlingFrictionScale(lpp);
        hookFlingAnimationScale(lpp);

        if (ENABLE_DURATION_CAP_FALLBACK) {
            hookSplineFlingDurationCap(lpp);
        }
    }

    /** Primary hook: neutralize the per-package friction scale (force DEFAULT_SCALE). */
    private void hookFlingFrictionScale(XC_LoadPackage.LoadPackageParam lpp) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.widget.UFwScrollerManager",
                lpp.classLoader,
                "getFlingFrictionScale",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Object original = param.getResult();
                        XposedBridge.log(TAG + ": getFlingFrictionScale(" + param.args[0]
                                + ") was " + original + " -> forcing 0.0 (DEFAULT_SCALE)");
                        param.setResult(0.0f);
                    }
                }
            );
            XposedBridge.log(TAG + ": getFlingFrictionScale hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": getFlingFrictionScale hook FAILED — " + t);
        }
    }

    /** Secondary hook: neutralize the per-package fling animation duration scale. */
    private void hookFlingAnimationScale(XC_LoadPackage.LoadPackageParam lpp) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.widget.UFwScrollerManager",
                lpp.classLoader,
                "getFlingAnimationScale",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Object original = param.getResult();
                        XposedBridge.log(TAG + ": getFlingAnimationScale(" + param.args[0]
                                + ") was " + original + " -> forcing 1.0");
                        param.setResult(1.0f);
                    }
                }
            );
            XposedBridge.log(TAG + ": getFlingAnimationScale hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": getFlingAnimationScale hook FAILED — " + t);
        }
    }

    /**
     * Fallback: caps the computed fling duration directly on the private
     * getSplineFlingDuration(int) method of OverScroller$SplineOverScroller.
     * This is real, non-native Dalvik bytecode (confirmed in classes4.dex),
     * so it's guaranteed hookable even if the UFwScrollerManager path above
     * turns out not to be on Instagram's actual call graph.
     */
    private void hookSplineFlingDurationCap(XC_LoadPackage.LoadPackageParam lpp) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.widget.OverScroller$SplineOverScroller",
                lpp.classLoader,
                "getSplineFlingDuration",
                int.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        int original = (int) param.getResult();
                        if (original > MAX_FLING_DURATION_MS) {
                            XposedBridge.log(TAG + ": getSplineFlingDuration was "
                                    + original + "ms -> capping to " + MAX_FLING_DURATION_MS + "ms");
                            param.setResult(MAX_FLING_DURATION_MS);
                        }
                    }
                }
            );
            XposedBridge.log(TAG + ": getSplineFlingDuration cap hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": getSplineFlingDuration cap hook FAILED — " + t);
        }
    }
}
